	
<div   class="cart_contain_side  side_cart"  style="overflow: auto  ; display: none  ;position: fixed !important ; width: 60% ;  top:100px  ;  z-index: 5000000000000; margin-left: 20% ;  margin-right: 20% ;">


<div  align="left"  class="col-sm-6"> <h3>Cart  </h3>  </div>





<div  align="right"   class="col-sm-6"> <h3> <span  onClick="$('.side_cart').fadeOut()"  class="glyphicon  glyphicon-remove "   style="cursor: pointer">  </span></h3>   </div>

 <hr/> 
 
<div  class="col-sm-12"   style="width: 100% ; margin: 0px">  <hr/>  </div>


<div   style=""  >

<div   class="col-sm-12"   id="cart_content"   style=" overflow: auto">


		
			</div>	
		
</div>
	<div  style="clear: both"> </div>
	<!--- place the signup buuton here--->
	<a   style="" href="/checkout/complete-order">
	<div    style="" >
	
	
	<button  class="btn-primary">Check out</button>
	
	


			
	</div>	</a>
	
	</div>