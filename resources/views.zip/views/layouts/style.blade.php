		
<style>
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.sp-wpcp-946 .wpcp-all-captions .wpcp-image-caption a,
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.sp-wpcp-946 .wpcp-all-captions .wpcp-image-caption {
			color: #ffffff;
			font-size: 11px;
			line-height: 13px;
			letter-spacing: 0px;
			text-transform: capitalize;
			text-align: center;
			font-family: Open Sans;
			font-weight: 600;
			font-style: normal;
		}
		#wpcpro-wrapper #sp-wp-carousel-pro-id-946.sp-wpcp-946 .wpcp-all-captions .wpcp-image-description {
			color: #333;
			font-size: 14px;
			line-height: 21px;
			letter-spacing: 0px;
			text-transform: none;
			text-align: center;}
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946 .slick-prev,
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946 .slick-next {
			color: #aaa;
			background-color: #fff;
			border-color: #aaa;
			border-radius: 0%;
		}
		#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946 .slick-prev:hover,
		#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946 .slick-next:hover {
			color: #fff;
			background-color: #18AFB9;
			border-color: #18AFB9;
		}
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.sp-wpcp-946.nav-vertical-center-inner-hover.slick-dotted .slick-next,
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946.nav-vertical-center-inner-hover.slick-dotted .slick-prev,
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946.nav-vertical-center-inner.slick-dotted .slick-next,
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946.nav-vertical-center-inner.slick-dotted .slick-prev,
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946.nav-vertical-center.slick-dotted .slick-next,
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946.nav-vertical-center.slick-dotted .slick-prev {
			margin-top: -35px;
		}
#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946 ul.slick-dots {
		margin: 18px 0px 0px 0px;
	}
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946 ul.slick-dots li button {
		background-color: #cccccc;
	}
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946 ul.slick-dots li.slick-active button {
		background-color: #52b3d9;
	}
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946:not(.wpcp-product-carousel) .wpcp-single-item {
		border: 0px solid #ffffff;
		padding: 0px;
	}

		.wpcp-carousel-wrapper.wpcp-wrapper-946{
			position: relative;
		}
		#wpcp-preloader-946{
			background: #fff;
			position: absolute;
			left: 0;
			top: 0;
			height: 100%;
			width: 100%;
			text-align: center;
			display: flex;
			align-items: center;
			justify-content: center;
			z-index: 999;
		}
		
			#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946 .slick-list {
			margin-right: -20px;
		}
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946 .slick-slide {
			margin-right: 20px;
		}
	@media screen and (min-width: 981px) {
		#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946:not(.wpcp-content-carousel) .wpcp-single-item img { max-height:300px; }
	}
	@media screen and (min-width: 737px) and (max-width: 980px) {
		#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946:not(.wpcp-content-carousel) .wpcp-single-item img { max-height:300px; }
	}
	@media screen and (min-width: 481px) and (max-width: 736px) {
		#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946:not(.wpcp-content-carousel) .wpcp-single-item img { max-height:200px; }
	}
	@media screen and  (max-width: 480px) {
		#wpcpro-wrapper #sp-wp-carousel-pro-id-946.wpcp-carousel-section.sp-wpcp-946:not(.wpcp-content-carousel) .wpcp-single-item img { max-height:180px; }
	}
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.sp-wpcp-946 .wpcp-slide-image img,
	#wpcpro-wrapper #sp-wp-carousel-pro-id-946.sp-wpcp-946.wpcp-product-carousel .wpcp-slide-image a {
		border-radius: 0px;
	}
		#wpcpro-wrapper #sp-wp-carousel-pro-id-946.sp-wpcp-946:not(.wpcp-product-carousel):not(.wpcp-content-carousel) .wpcp-single-item {
			background: rgba(249,249,249,0);
		}#wpcpro-wrapper .wpcp-carousel-section.wpcp-image-carousel .wpcp-single-item .wpcp-all-captions { min-height: 50px; padding: 10px; }

#wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions h2 a { font-family: 'gothammedium' !important; }
#wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions p { font-family: 'gothambookregular' !important; }

#wpcpro-wrapper #sp-wp-carousel-pro-id-771.wpcp-carousel-section.wpcp-image-carousel .wpcp-single-item .wpcp-all-captions { background-color: #d2d9de; }

#wpcpro-wrapper #sp-wp-carousel-pro-id-798.sp-wpcp-798 .wpcp-all-captions .wpcp-image-caption a { color: {{ config('app.color2') }};}
#wpcpro-wrapper #sp-wp-carousel-pro-id-798.sp-wpcp-798 .wpcp-all-captions .wpcp-image-description {color: #fff;}
#wpcpro-wrapper #sp-wp-carousel-pro-id-798.wpcp-carousel-section.wpcp-image-carousel .wpcp-single-item .wpcp-all-captions {background-color: {{ config('app.color') }} !important;}


@media screen and (max-width: 767px) 
{
    #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions h2,  
    #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions h2 a {font-size: 10px !important; line-height: 10px !important;} 
    #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions p  {font-size:10px !important; line-height: 10px !important; }
    #wpcpro-wrapper .wpcp-carousel-section.wpcp-image-carousel .wpcp-single-item .wpcp-all-captions { min-height: 45px !important; padding: 10px 10px 7.5px !important; } 
}



/*-------ORDER BUTTONS-------*/
#wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item { position: relative; }

#wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions:after {
    content: "order";
    position: absolute;
    right: 10px;
    bottom: 60px;
    color: #ffffff;
    background: {{ config('app.color') }};
    border:3px solid {{ config('app.color') }};
    padding: 0px 20px 2px 20px;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
    font-size: 15px;
    line-height: 17px;
    -webkit-transition: all 0.3s linear;
    -moz-transition: all 0.3s linear;
    -ms-transition: all 0.3s linear;
    -o-transition: all 0.3s linear;
    transition: all 0.3s linear;  
}

#wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions:hover:after
{
    color: {{ config('app.color') }};
    background: {{ config('app.color2') }};
}

/* -- Red Version with Black Button -- */
#red-carousel #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions:after
{
    background: #201e1e;
    border:3px solid #201e1e;
}
#red-carousel #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions:hover:after
{
    background: #ffffff;
    border:3px solid #201e1e;
    color: {{ config('app.color') }};
    font-weight:bold;
}


@media screen and (max-width: 767px) 
{
    #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions:after 
    { 
        bottom: 55px; 
        right: 5px;
        font-size: 10px;
        line-height: 12px;
        padding: 0px 5px;
    }
}


/*-------MENU ICONS-------*/
#menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item { width:100% !important; }
#menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions {
    padding: 5px 0px 0px 0px; 
    background: none; 
    background-color: none !important; 
    min-height: 10px !important; }
#menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions h2 a {font-family: 'gothambookregular' !important; }

#menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions:after { content: none; }
#menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-slide-image { 
    background: {{ config('app.color') }};
    border-radius: 50%;
    width: 50%;
    margin: 0 auto;}

#menu-icons #wpcpro-wrapper .slick-track .slick-slide div a:hover .wpcp-single-item .wpcp-slide-image img { background: {{ config('app.color2') }}; } 
#menu-icons #wpcpro-wrapper .slick-track .slick-slide div a:hover .wpcp-single-item .wpcp-all-captions h2 a  { color:{{ config('app.color') }}; }

@media only screen and (max-width: 554px)
{
    #menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item { width:100% !important; }
    #menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-slide-image { width:100% !important; }
    #menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions { padding: 10px 0px 0px 0px !important; min-height: 30px;   } 
    #menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions * { font-family: 'gothambookregular' !important; } 
}

/*-------HOME PAGE MENU ICONS-------*/
#home-menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item { width:100% !important; }
#home-menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions {
    padding: 5px 0px 0px 0px; 
    background: none; 
    background-color: none !important; 
    min-height: 10px !important; }
#home-menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions h2 a {font-family: 'gothambookregular' !important; }

#home-menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions:after { content: none; }
#home-menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-slide-image { 
    background: #ffffff;
    border-radius: 50%;
    width: 50%;
    margin: 0 auto;}

#home-menu-icons #wpcpro-wrapper .slick-track .slick-slide div a:hover .wpcp-single-item .wpcp-slide-image img { background: {{ config('app.color2') }}; } 
#home-menu-icons #wpcpro-wrapper .slick-track .slick-slide div a:hover .wpcp-single-item .wpcp-all-captions h2 a  { color:{{ config('app.color2') }}; }

@media only screen and (max-width: 554px)
{
    #home-menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item { width:100% !important; }
    #home-menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-slide-image { width:100% !important; }
    #home-menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions { padding: 10px 0px 0px 0px !important; min-height: 30px;   } 
    #home-menu-icons #wpcpro-wrapper .slick-track .slick-slide .wpcp-single-item .wpcp-all-captions * { font-family: 'gothambookregular' !important; } 
}


		</style>
		
		
		