@extends('admin_dashboar')
@section('content')	


<div>
	 products 
	
	
</div>


@endsection