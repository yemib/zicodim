<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cart_list extends Model
{
    //
}
