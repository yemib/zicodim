<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class admin_user extends Model
{
    //
}
