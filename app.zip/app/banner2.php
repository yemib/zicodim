<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class banner2 extends Model
{
    //
}
