<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cart_container extends Model
{
    //
}
