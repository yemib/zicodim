<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pickup extends Model
{
    //
}
