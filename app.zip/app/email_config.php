<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class email_config extends Model
{
    //
}
