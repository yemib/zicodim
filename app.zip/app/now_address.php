<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class now_address extends Model
{
    //
}
