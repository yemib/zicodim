<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pages extends Model
{
    //
}
