<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class banner1 extends Model
{
    //
}
