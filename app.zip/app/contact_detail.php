<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contact_detail extends Model
{
    //
}
