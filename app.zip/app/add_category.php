<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class add_category extends Model
{
    //
}
