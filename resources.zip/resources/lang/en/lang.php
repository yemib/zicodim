<?php
   return [
      'msg' => 'Laravel Internationalization example.'
   ];
?>