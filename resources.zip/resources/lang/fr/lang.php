<?php
   return [
      'msg' => 'Exemple Laravel internationalisation.'
   ];
?>