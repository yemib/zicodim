<style>
        .remove-btn {
            cursor: pointer;
            color: red;
            margin-left: 10px;
        }
    </style>

    <style>
        .drop-container {
            margin-bottom: 20px;
        }

        .drop-area {
            border: 2px dashed #ccc;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            background-color: #f9f9f9;
            border-radius: 10px;
            transition: border-color 0.3s ease-in-out, background-color 0.3s ease-in-out;
        }

        .drop-area.highlight {
            border-color: #3498db;
            background-color: #f2f9ff;
        }

        .file-list {
            list-style-type: none;
            padding: 0;
        }

        .file-item {
            background-color: #f2f2f2;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease-in-out, background-color 0.3s ease-in-out;
        }

        .file-item:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #e6e6e6;
        }

        /* 	button[type="submit"] {
      padding: 10px 20px;
      background-color: #3498db;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease-in-out;
     }
     
     button[type="submit"]:hover {
      background-color: #2980b9;
     } */
    </style>
