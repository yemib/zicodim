
        
    <a  href="/">  <button type="button" class="btn btn-default">	 Home </button></a>
    
    
    
    <a  href="/dashboard">  <button type="button" class="btn btn-default">	 Dashboard  </button></a>
      
      	
   <hr/>


   <a  href="/email_accounts">  <button style="width: 100%"  type="button" class="btn btn-default">	Emails account </button></a>
      
   <hr/>
      
      <?php  groupbutton('Manage Category', "Add" , "List" , "/add_category"  ,"/list_category") ?>
             

           <hr/>
           
            <?php  groupbutton('Products', "Add" , "List" , "/add_product"  ,"/list_product") ?>
  

            
           <hr/>
           
      <?php  //groupbutton('Article', "Add" , "List" , "/article/create"  ,"/article") ?>
      
            
         
                                        
               <div class="btn-group" role="group">
        <button id="btnDropOne1" type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">  Orders <span class="caret"></span></button>
        
        <ul class="dropdown-menu" aria-labelledby="btnDropOne1">
         
     <li><a  href="/progress_order">Progress  Order List</a></li>
       
		<li><a  href="/complete_order"> Complete Order  List</a></li>
       
       
       <li><a  href="/cancel_order"> Cancel Order  List</a></li>
       
       
        </ul>
      
      </div>
          
          <hr/>
      <?php  groupbutton('Slider Setting', "Add" , "List" , "/sliders"  ,"/list_sliders") ?>
     <hr/>

     <?php  groupbutton('Portfolio Setting', "Add" , "List" , "/iconses"  ,"/list_icons") ?>
     <hr/>
         
             
                
                
      <a  href="/logo">  <button   style="width: 100%" type="button" class="btn btn-default">	 Change Logo </button></a>             
                     
                  <hr/>
                             
               <a  href="/customer">  <button   style="width: 100%" type="button" class="btn btn-default">	 Customers </button></a>   
             
   <hr/>
      
      
               
               <div class="btn-group" role="group">
        <button id="btnDropOne1" type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">   Pages <span class="caret"></span></button>
        
        <ul class="dropdown-menu" aria-labelledby="btnDropOne1">
   <!--      
     <li><a  href="/pages/home"> Home </a></li>
       
          
		<li><a  href="/pages/faqs">  FAQs</a></li>     --->
       
       <li><a    href="/pages/privacy">  Privacy Policy</a></li> 
       
          <li><a  href="/pages/terms">   Terms &amp;  Conditions</a></li>
           
           
           <li><a  href="/pages/about">   About  </a></li>
       
       
        </ul>
      
      </div>
          
                   <hr/>
                    
                <a  href="/contact_details">  <button   style="width: 100%" type="button" class="btn btn-default">	 Contacts </button></a>   
                
                <hr/>
      
      
      <?php  groupbutton('Admins', "Add" , "List" , "/add_user"  ,"/list_user") ?>
           
       
    
        
          <!--
                <a  href="/font_change">  <button   style="width: 100%" type="button" class="btn btn-default">	 Font </button></a>
                       
                       <br/>
                       <br/> -->

               <!---
                <a  href="/color">  <button   style="width: 100%" type="button" class="btn btn-default">	 Change Color </button></a>
                --->
                
           <br/>         
           <br/>         
           <br/>         
            